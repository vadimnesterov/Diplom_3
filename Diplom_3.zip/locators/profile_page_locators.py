from selenium.webdriver.common.by import By


class ProfilePageLocators:
    # Заголовок страницы профиля
    PROFILE_HEADER = (By.XPATH, "//h2[text()='Профиль']")

    # Поля профиля (если понадобятся дальше)
    NAME_INPUT = (By.XPATH, "//label[text()='Имя']/following-sibling::input")
    EMAIL_INPUT = (By.XPATH, "//label[text()='Логин']/following-sibling::input")

    # Кнопка «Выход» на странице профиля
    LOGOUT_BUTTON = (By.XPATH, "//button[text()='Выход']")
