from pages.base_page import BasePage
from locators.profile_page_locators import ProfilePageLocators


class ProfilePage(BasePage):

    def is_profile_open(self) -> bool:
        """Проверить загрузку страницы профиля."""
        return self.is_visible(ProfilePageLocators.PROFILE_HEADER)
